<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

<head>
<meta name="robots" content="noindex,nofollow">

<title>SquirrelMail</title><script language="JavaScript" type="text/javascript">
<!--
function checkForm() {
   var f = document.forms.length;
   var i = 0;
   var pos = -1;
   while( pos == -1 && i < f ) {
       var e = document.forms[i].elements.length;
       var j = 0;
       while( pos == -1 && j < e ) {
           if ( document.forms[i].elements[j].type == 'text'            || document.forms[i].elements[j].type == 'password' ) {
               pos = j;
           }
           j++;
       }
   i++;
   }
   if( pos >= 0 ) {
       document.forms[i-1].elements[pos].focus();
   }
   
}
// -->
</script>

<!--[if IE 6]>
<style type="text/css">
/* avoid stupid IE6 bug with frames and scrollbars */
body {
    width: expression(document.documentElement.clientWidth - 30);
}
</style>
<![endif]-->

</head>

<body text="#000000" bgcolor="#ffffff" link="#0000cc" vlink="#0000cc" alink="#0000cc" onload="checkForm();">

<a name="pagetop"></a>
<table bgcolor="#ffffff" border="0" width="100%" cellspacing="0" cellpadding="2">

<tr bgcolor="#ababab">

<td align="left">

&nbsp;      </td>
<td align="right">
<b>
<a href="/webmail/src/signout.php" target="_top">Sign Out</a></b></td>
   </tr>
<tr bgcolor="#ffffff">

<td align="left">

<a href="/webmail/src/compose.php?mailbox=None&amp;startMessage=0">Compose</a>&nbsp;&nbsp;
<a href="/webmail/src/addressbook.php">Addresses</a>&nbsp;&nbsp;
<a href="/webmail/src/folders.php">Folders</a>&nbsp;&nbsp;
<a href="/webmail/src/options.php">Options</a>&nbsp;&nbsp;
<a href="/webmail/src/search.php?mailbox=None">Search</a>&nbsp;&nbsp;
<a href="/webmail/src/help.php">Help</a>&nbsp;&nbsp;
<a href="/webmail/plugins/calendar/calendar.php" target="right">Calendar</a>&nbsp;&nbsp;
      </td>
<td align="right">

<a href="http://www.squirrelmail.org/" target="_blank">SquirrelMail</a></td>
   </tr>
</table><br>

<br /><table width="100%" border="0" cellspacing="0" cellpadding="2" align="center"><tr><td bgcolor="#dcdcdc">
<b><center>
Viewing a text attachment - <a href="read_body.php?mailbox=INBOX&passed_id=4286&startMessage=1">View message</a></b></td><tr><tr><td><center>
<a href="../src/download.php?mailbox=INBOX&passed_id=4286&startMessage=1&ent_id=3&amp;absolute_dl=true">Download this as a file</a></center><br />
</center></b>
</td></tr></table>
<table width="98%" border="0" cellspacing="0" cellpadding="2" align="center"><tr><td bgcolor="#dcdcdc">
<tr><td bgcolor="#ffffff"><tt>
<pre>x
-1.4209903
-1.2773842
-1.0197199
-1.0165501
-0.7642005
-0.7547988
-0.650272
-0.6291661
-0.5232639
-0.3544043
0.4398519
0.7137376
0.9099341
0.9579163
1.0781161
1.149384
1.1526664
1.1773254
1.3413419
1.8661013
</pre></tt></td></tr></table>
</body></html>